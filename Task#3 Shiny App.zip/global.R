#######################################################
#              Text Analytics Shiny App               #
#                     (global.R)                      #
#             Laukik Kalelkar - 11920009              #
#             Rajesh Margabandhu - 11920095           #
#             Kartik Mishra - 11920039                #
#             Prashant Khare - 11920035               #
#             Amol Kulkarni - 11920083                #
#######################################################

#######################################################
# 1. Install/Load Required Packages 
#######################################################
suppressPackageStartupMessages({
  require(shiny) || install.packages("shiny")
  library(shiny)
  require(dplyr) || install.packages("dplyr")
  library(dplyr)
  require(tidytext) || install.packages("tidytext")
  library(tidytext)
  require(tibble) || install.packages("tibble")
  library(tibble)
  require(tidyverse) || install.packages("tidyverse")
  library(tidyverse)
  require(ggplot2) || install.packages("ggplot2")
  library(ggplot2)
  require(wordcloud) || install.packages("wordcloud")
  library(wordcloud)
})  

#######################################################
# 2. Global Variable(s) 
#######################################################

# Reviews File
inputFileTag <- "Reviews File"

inputFileHeaderDefault <- "Reviews"

inputFileDescription <- "The App will sentence tokenise the input file based on the keyword(s) provided. \
                         It supports only comma separated values (CSV) input data file with headers as the first row."
inputFileNote <- "<p style='color:Red;'>Note - The input CSV file MUST contain <b>'Reviews'</b> (case-sensitive) as one of the header columns.<p>"  

# Search Keyword(s)
inputKeywordsTag <- "Search Keyword(s)"

inputKeywordsDescription <- "You can specify comma seperated input keyword(s) for sentence tokenisation."

inputKeywordsDefault <- "engine,mileage,comfort,performance,interior,maintenance,price"

#######################################################
# 3. Global Function(s) 
#######################################################

# Read Reviews File
readReviewsFile <- function( csvFile ) {
                                         print ( "Reading Reviews File Begins" )
                                         output = NULL 
                                         if ( is.null( csvFile ) ) {
                                            output = NULL
                                         } else {
                                            output <- read_csv( csvFile, col_names = TRUE )
                                            if ( is.null( output ) ) {
                                                print ( "Reviews File Not Uploaded" )
                                                output = NULL
                                            } else if ( is.data.frame( output ) && nrow( output ) == 0 ) {
                                                print ( "Reviews File Uploaded, But is Empty" )
                                                output = NULL
                                            } else if ( is.data.frame( output ) && !( inputFileHeaderDefault %in% colnames( output ) ) ) {
                                                print ( "Reviews File Uploaded, But Does Not Contain [Reviews] Column" )
                                                output = NULL
                                            } else {
                                                output = output %>%
                                                         select( inputFileHeaderDefault )
                                            }
                                         }
                                         
                                         return ( output )
                   }


# Check Whether Search Text Given
isSearchText <- function ( input, text ) {
                                           print( "Checking Whether Search Text Provided Begins")
                                           isGiven = FALSE 
                                           if ( is.null( input ) ) {
                                               isGiven = FALSE
                                           } else {
                                               if ( is.null( text ) ) {
                                                   isGiven = FALSE
                                               } else if ( text == "" ) {
                                                   cat ( paste( "Search Text is empty\n" ) )
                                                   isGiven = TRUE
                                               } else {
                                                   cat ( paste( "Search Text [", text , "] is given\n" ) )
                                                   isGiven = TRUE
                                               }
                                           }
                                           return ( isGiven )
                }

# Get Filtered Reviews Based On Search Text
# If tfidf Is Passed As TRUE, additionally it will generate a DTM
# If bc Is Passed As TRUE, additionally it will generate a Bar Chart
# If wc Is Passed As TRUE, additionally it will generate a Word Cloud
# If ngrams = 1, then unigram, if ngrams = 2 then bigram
getFilteredReviews <- function( input, text, tfidf = FALSE, ngrams = 1, 
                                bc = FALSE, wc = FALSE ) {
                                                           output = input %>%
                                                                    mutate( Doc = row_number() ) %>%
                                                                    unnest_tokens( Sentence, Reviews, token = "sentences" )
                                                               
                                                           if ( text != "" ) {
                                                               text = text %>%
                                                                      str_replace_all( c( "\\\\s+" = " " ) ) %>%
                                                                      str_replace_all( c( " , " = "," ) )  %>%
                                                                      #str_replace_all( c( " " = "\\\\b" ) )  %>%
                                                                      str_replace_all( c( "," = "\\\\b|\\\\b" ) )
                                                               text = paste( "\\b", text, "\\b", sep = "" )
                                                               cat ( paste ( "Filter Text [",  text,  "]" ) )
                                                               output = output %>%
                                                                        filter( grepl( text, Sentence, ignore.case = TRUE ) )   
                                                           }
                                                           
                                                           if ( nrow( output ) == 0 ) {
                                                               return (NULL)
                                                           } else if ( tfidf == TRUE || bc == TRUE || wc == TRUE ) {
                                                               output = output %>%
                                                                        unnest_tokens( Word, Sentence, token = "ngrams", n = ngrams ) %>%
                                                                        group_by( Doc ) %>%
                                                                        count( Word, sort = TRUE ) %>%
                                                                        filter( grepl( text, Word, ignore.case = TRUE ) )
                                                               
                                                               output = output %>% 
                                                                        group_by( Doc ) %>% 
                                                                        count( Word, sort = TRUE ) %>% 
                                                                        ungroup() %>%
                                                                        bind_tf_idf( Word, Doc, n ) %>%
                                                                        rename( value = tf_idf )
                                                               
                                                               output = output %>% cast_sparse( Doc, Word, value )
                                                               
                                                               colsum = apply( output, 2, sum )    
                                                               col.order = order( colsum, decreasing = TRUE )
                                                               row.order = order( rownames(output) %>% as.numeric() )
                                                               
                                                               output = output[row.order, col.order]
                                                               if ( bc == TRUE ) {
                                                                   a0 = apply( output, 2, sum )
                                                                   a1 = order( a0, decreasing = TRUE )
                                                                   tsum = a0[a1]
                                                                   barChartTokens = length(tsum)
                                                                   
                                                                   test = as.data.frame( round( tsum[ 1:barChartTokens ], 0) )
                                                                   
                                                                 
                                                                   barchartPlot = ggplot( test, aes( x = rownames( test ), y = test[,] ) ) + 
                                                                                  geom_bar( stat = "identity", fill = "Red" ) +
                                                                                  geom_text( aes( label = test[,] ), vjust= -0.20 ) + 
                                                                                  theme( axis.text.x = element_text( angle = 90, hjust = 1 ) )
                                                                 
                                                                   plot(barchartPlot)
                                                               } else if ( wc == TRUE ) {
                                                                 
                                                                   if ( ncol( output ) > 20000 ) {
                                                                   
                                                                       tst = round( ncol( dtm ) / 100 ) 
                                                                       a = rep( tst, 99 )
                                                                       b = cumsum( a ); rm( a )
                                                                       b = c( 0, b, ncol( dtm ) )
                                                                   
                                                                       ss.col = c( NULL )
                                                                   
                                                                       for ( i in 1:( length( b ) - 1 ) ) {
                                                                           tempdtm = output[,( b[ i ] + 1 ):( b[ i + 1 ] ) ]
                                                                           s = colSums( as.matrix( tempdtm ) )
                                                                           ss.col = c( ss.col, s )
                                                                           print( i )
                                                                       }
                                                                   
                                                                       tsum = ss.col
                                                                   
                                                                   } else { 
                                                                       tsum = apply( output, 2, sum )
                                                                   }
                                                                 
                                                                   tsum = tsum[ order( tsum, decreasing = TRUE ) ]
                                                                 
                                                                   head( tsum )
                                                                 
                                                                   tail( tsum )
                                                                 
                                                                   wordcloud( names(tsum), tsum,     
                                                                              scale = c(3.5, 0.5),    
                                                                              5,               
                                                                              max.words = 150, 
                                                                              colors = brewer.pal( 8, "Dark2" ) )
                                                                 
                                                                   title( sub = "wordcloud" )
                                                               }
                                                           } else {
                                                              return ( output )  
                                                           }

                                                           
                      }
