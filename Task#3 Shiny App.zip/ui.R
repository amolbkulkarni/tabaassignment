#######################################################
#              Text Analytics Shiny App               #
#                        (ui.R)                       #
#             Laukik Kalelkar - 11920009              #
#             Rajesh Margabandhu - 11920095           #
#             Kartik Mishra - 11920039                #
#             Prashant Khare - 11920035               #
#             Amol Kulkarni - 11920083                #
#######################################################

#######################################################
# 1. Define UI Layout 
#######################################################

shinyUI( fluidPage (

                    # Application Title
                    titlePanel( "Sentence Tokenizer" ),
                    
                    # Sidebar Layout
                    sidebarLayout(
                                   # Sidebar Panel Layout        
                                   sidebarPanel(
                                                 fileInput( "reviewsFile", inputFileTag, accept = c( "text/csv", "text/comma-separated-values,text/plain", ".csv" )
                                                 ),
                                                 textInput( "searchKeywords", inputKeywordsTag, placeholder = inputKeywordsDefault
                                                 ) 
                                   ), # sidebarPanel
                        
                                   # Main Panel Layout
                                   mainPanel(
                                              # Tabset Panel Layout 
                                              tabsetPanel( type = "tabs",
                                                           tabPanel( h5( "App Usage" ),
                                                                     h4( p( inputFileTag ) ),
                                                                     p( inputFileDescription, align = "justify" ),
                                                                     p( HTML(inputFileNote), align = "justify" ),
                                                                     p( a( href = "https://github.com/amolbkulkarni/tabaassignment/blob/master/Car%20Reviews%20Data.csv", target="_blank", "Sample Input File" ), align = "justify"),
                                                                     br(),
                                                                     h4( p( inputKeywordsTag ) ),
                                                                     p( inputKeywordsDescription, align = "justify" )
                                                           ), # tabPanel 1
                                                           tabPanel( h5( "Filtered Reviews" ),
                                                                     tableOutput( "filteredReviews" )  
                                                           ), # tabPanel 2  
                                                           tabPanel( h5( "Keyword(s) Occurrence (unigram) - Bar Chart" ),
                                                                     plotOutput( "filteredReviewsBC1" )  
                                                           ), # tabPanel 3
                                                           tabPanel( h5( "Keyword(s) Occurrence (unigram) - Word Cloud" ),
                                                                     plotOutput( "filteredReviewsWC1" )
                                                           ), # tabPanel 4
                                                           tabPanel( h5( "Keyword(s) Occurrence (bigram) - Bar Chart" ),
                                                                     plotOutput( "filteredReviewsBC2" )  
                                                           ), # tabPanel 5
                                                           tabPanel( h5( "Keyword(s) Occurrence (bigram) - Word Cloud" ),
                                                                     plotOutput( "filteredReviewsWC2" )
                                                           ) # tabPanel 4
                                            ) # tabsetPanel
                                   ) # mainPanel
                    ) # sidebarLayout
         ) # fluidPage
) # shinyUI