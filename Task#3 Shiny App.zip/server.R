#######################################################
#              Text Analytics Shiny App               #
#                     (server.R)                      #
#             Laukik Kalelkar - 11920009              #
#             Rajesh Margabandhu - 11920095           #
#             Kartik Mishra - 11920039                #
#             Prashant Khare - 11920035               #
#             Amol Kulkarni - 11920083                #
#######################################################

#######################################################
# 1. Define Server Functions 
#######################################################

shinyServer( function( input, output ) {
                                         print ( "Shiny Server Function Initialised"  )
                                         filterReviews <- reactive( {
                                                                       print( "Filtering Reviews (reactive) Begins")
                                                                       searchKeywords <- input$searchKeywords
                                                                       reviewsFile <- input$reviewsFile
                                                                       cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                       cat ( paste( "Search Keyword(s) -> [", searchKeywords, "]\n" ) )
                                                                       reviews <- readReviewsFile( reviewsFile$datapath )
                                                                       if ( isSearchText( reviews, searchKeywords ) ) {
                                                                           getFilteredReviews( reviews, searchKeywords )
                                                                       }
                                                                     }    
                                                          ) # reactive

                                         filterReviewsBC1 <- reactive( {
                                                                         print( "Filtering Reviews BC (unigram) (reactive) Begins")
                                                                         searchKeywords <- input$searchKeywords
                                                                         reviewsFile <- input$reviewsFile
                                                                         cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                         cat ( paste( "Search Keyword(s) -> [", searchKeywords, "]\n" ) )
                                                                         reviews <- readReviewsFile( reviewsFile$datapath )
                                                                         if ( isSearchText( reviews, searchKeywords ) ) {
                                                                             getFilteredReviews( reviews, searchKeywords, tfidf = TRUE, bc = TRUE, ngrams = 1 )
                                                                         }
                                                                       }    
                                                             ) # reactive

                                         filterReviewsWC1 <- reactive( {
                                                                         print( "Filtering Reviews WC (unigram) (reactive) Begins")
                                                                         searchKeywords <- input$searchKeywords
                                                                         reviewsFile <- input$reviewsFile
                                                                         cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                         cat ( paste( "Search Keyword(s) -> [", searchKeywords, "]\n" ) )
                                                                         reviews <- readReviewsFile( reviewsFile$datapath )
                                                                         if ( isSearchText( reviews, searchKeywords ) ) {
                                                                             getFilteredReviews( reviews, searchKeywords, tfidf = TRUE, wc = TRUE, ngrams = 1 )
                                                                         }
                                                                       }    
                                                             ) # reactive
                                         
                                         filterReviewsBC2 <- reactive( {
                                                                         print( "Filtering Reviews BC (bigram) (reactive) Begins")
                                                                         searchKeywords <- input$searchKeywords
                                                                         reviewsFile <- input$reviewsFile
                                                                         cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                         cat ( paste( "Search Keyword(s) -> [", searchKeywords, "]\n" ) )
                                                                         reviews <- readReviewsFile( reviewsFile$datapath )
                                                                         if ( isSearchText( reviews, searchKeywords ) ) {
                                                                             getFilteredReviews( reviews, searchKeywords, tfidf = TRUE, bc = TRUE, ngrams = 2 )
                                                                         }
                                                                       }    
                                                             ) # reactive
                                         
                                         filterReviewsWC2 <- reactive( {
                                                                         print( "Filtering Reviews WC (bigram) (reactive) Begins")
                                                                         searchKeywords <- input$searchKeywords
                                                                         reviewsFile <- input$reviewsFile
                                                                         cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                         cat ( paste( "Search Keyword(s) -> [", searchKeywords, "]\n" ) )
                                                                         reviews <- readReviewsFile( reviewsFile$datapath )
                                                                         if ( isSearchText( reviews, searchKeywords ) ) {
                                                                             getFilteredReviews( reviews, searchKeywords, tfidf = TRUE, wc = TRUE, ngrams = 2 )
                                                                         }
                                                                       }    
                                                             ) # reactive
                                         
                                         output$filteredReviews <- renderTable( {
                                                                                  print( "Rendering Filtered Reviews (renderTable) Begins")
                                                                                  reviewsFile <- input$reviewsFile
                                                                                  cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                                  if ( is.null( reviewsFile ) ) {
                                                                                      return( NULL )
                                                                                  } else {
                                                                                      filteredReviews <- filterReviews()
                                                                                      return( filteredReviews )
                                                                                  }
                                                                                }
                                                                   ) # renderTable
                                         
                                         output$filteredReviewsBC1 <- renderPlot( {
                                                                                    print( "Rendering Filtered Reviews BC (unigram) (renderTable) Begins")
                                                                                    reviewsFile <- input$reviewsFile
                                                                                    cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                                    if ( is.null( reviewsFile ) ) {
                                                                                        return( NULL )
                                                                                    } else {
                                                                                        filteredReviewsBC1 <- filterReviewsBC1()
                                                                                        return( filteredReviewsBC1 )
                                                                                    }
                                                                                  }
                                                                   ) # renderPlot
                                         
                                         output$filteredReviewsWC1 <- renderPlot( {
                                                                                    print( "Rendering Filtered Reviews WC (unigram) (renderTable) Begins")
                                                                                    reviewsFile <- input$reviewsFile
                                                                                    cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                                    if ( is.null( reviewsFile ) ) {
                                                                                        return( NULL )
                                                                                    } else {
                                                                                        filteredReviewsWC1 <- filterReviewsWC1()
                                                                                        return( filteredReviewsWC1 )
                                                                                    }
                                                                                  }
                                                                      ) # renderPlot  
                                        
                                         output$filteredReviewsBC2 <- renderPlot( {
                                                                                    print( "Rendering Filtered Reviews BC (bigram) (renderTable) Begins")
                                                                                    reviewsFile <- input$reviewsFile
                                                                                    cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                                    if ( is.null( reviewsFile ) ) {
                                                                                        return( NULL )
                                                                                    } else {
                                                                                        filteredReviewsBC2 <- filterReviewsBC2()
                                                                                        return( filteredReviewsBC2 )
                                                                                    }
                                                                                  }
                                                                      ) # renderPlot
                                         
                                         output$filteredReviewsWC2 <- renderPlot( {
                                                                                    print( "Rendering Filtered Reviews WC (bigram) (renderTable) Begins")
                                                                                    reviewsFile <- input$reviewsFile
                                                                                    cat ( paste( "Reviews File -> [", reviewsFile, "]\n" ) )
                                                                                    if ( is.null( reviewsFile ) ) {
                                                                                        return( NULL )
                                                                                    } else {
                                                                                        filteredReviewsWC2 <- filterReviewsWC2()
                                                                                        return( filteredReviewsWC2 )
                                                                                    }
                                                                                  }
                                                                      ) # renderPlot  
                                         
             } # function
) # shinyServer
